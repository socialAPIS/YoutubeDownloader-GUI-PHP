<?php

namespace YoutubeDownloader\Router;

interface RouteInfoInterface {

    /**
     * @return RouteInfoModel
     */
    public function getRouteInfo();
}
